﻿internal static class _ERCompVersionInfoCommon
{
[System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields" )]
  public const string Build = ".*";

}
