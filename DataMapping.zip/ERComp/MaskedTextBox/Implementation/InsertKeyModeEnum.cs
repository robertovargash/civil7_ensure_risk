﻿/*************************************************************************************

   

   

   This program is provided to you under the terms of the Microsoft Public
    

   For more features, controls, and fast professional support,
    

    

  ***********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace ERComp
{
  public enum InsertKeyMode
  {
    Default = 0,
    Insert = 1,
    Overwrite = 2
  }
}
