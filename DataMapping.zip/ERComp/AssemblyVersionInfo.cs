﻿#pragma warning disable 0436
[assembly: System.Reflection.AssemblyVersion( _ERCompInfo.Version )]
#pragma warning restore 0436

internal static class _ERCompInfo
{
  [System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields" )]
  public const string BaseVersion = "3.5";
  [System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields" )]
  public const string Version = BaseVersion + 
  ".0.0";
  [System.Diagnostics.CodeAnalysis.SuppressMessage( "Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields" )]
  public const string PublicKeyToken = "ba83ff368b7563c6";


}
