﻿/*************************************************************************************

   

   

   This program is provided to you under the terms of the Microsoft Public
    

   For more features, controls, and fast professional support,
    

    

  ***********************************************************************************/

namespace ERComp
{
  internal static partial class VisualStates
  {
    public const string MessageBoxButtonsGroup = "MessageBoxButtonsGroup";
    public const string OK = "OK";
    public const string OKCancel = "OKCancel";
    public const string YesNo = "YesNo";
    public const string YesNoCancel = "YesNoCancel";
  }
}
