﻿/*************************************************************************************

   

   

   This program is provided to you under the terms of the Microsoft Public
    

   For more features, controls, and fast professional support,
    

    

  ***********************************************************************************/

namespace ERComp
{
  public enum PieMode
  {
    Manual,
    EndAngle,
    Slice,
  }
}
