﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnsureRisk.Classess
{
    public enum MRLimited
    {
        EditRisk = 0,
        Scope = 1,
        Copy = 2,
        Enable = 3
    }
}
