﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnsureBusinesss.Business
{
    public class LineGroup
    {
        public decimal IdGroup { get; set; }
        public string GroupName { get; set; }

        public LineGroup()
        {

        }
    }
}
