﻿using System.Windows;

namespace EnsureBusinesss
{
    public static class Messages
    {
        //public static void ErrorMessage(string message) => MessageBox.Show(message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);

        //public static void InformationMessage(string message) => MessageBox.Show(message, "Information", MessageBoxButton.OK, MessageBoxImage.Information);

        //public static void WarningMessage(string message) => MessageBox.Show(message, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}
