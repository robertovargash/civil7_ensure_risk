﻿/*************************************************************************************

   

   

   This program is provided to you under the terms of the Microsoft Public
    

   For more features, controls, and fast professional support,
    

    

  ***********************************************************************************/

using System.Windows.Controls;

namespace ERComp.Panels
{
  public abstract class PanelBase : Panel
  {
    #region Constructor

    public PanelBase()
    {
    }

    #endregion
  }
}
