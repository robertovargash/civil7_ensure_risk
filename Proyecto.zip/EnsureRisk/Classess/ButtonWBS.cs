﻿using System.Windows.Controls;

namespace EnsureRisk.Classess
{
    public class ButtonWBS:Button
    {
        public decimal IdWBS { get; set; }

        public ButtonWBS():base()
        {

        }
    }
}
